<?php
/**
 * Copyright(c) 2019 SYSTEM_KD
 * Date: 2019/03/21
 */

namespace Plugin\QuantityDiscount\Service\TwigRenderService\builder\base;


/**
 * Interface ContentBlockBuilderInterface
 */
interface ContentBlockBuilderInterface
{
    public function build();
}
